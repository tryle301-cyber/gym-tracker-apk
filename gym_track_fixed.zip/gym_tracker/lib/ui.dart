import 'dart:math' as math;
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'data.dart';

bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
bool isAmoled(BuildContext c) => Theme.of(c).scaffoldBackgroundColor == Colors.black;
Color bgOf(BuildContext c) => Theme.of(c).scaffoldBackgroundColor;
Color cardOf(BuildContext c) => isAmoled(c)
    ? const Color(0xFF0F0F12)
    : (isDark(c) ? const Color(0xFF161C23) : const Color(0xFFF7FAFD));
Color fieldOf(BuildContext c) => isAmoled(c)
    ? const Color(0xFF1B1B20)
    : (isDark(c) ? const Color(0xFF222B35) : const Color(0xFFDCE5EF));
Color subtleOf(BuildContext c) => isDark(c) ? Colors.white54 : Colors.black54;
Color accentOf(BuildContext c) => Theme.of(c).colorScheme.primary;

Future<void> applyRefresh(bool on) async {
  try {
    await const MethodChannel('gym/display').invokeMethod('setHighRefresh', {'on': on});
  } catch (_) {}
}

ThemeData buildTheme(Brightness b, {bool amoled = false}) {
  final dark = b == Brightness.dark;
  final accent = dark ? const Color(0xFF3AA0FF) : const Color(0xFF1F6FEB);
  final scheme = ColorScheme.fromSeed(seedColor: accent, brightness: b)
      .copyWith(primary: accent, onPrimary: Colors.white);
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: scheme,
    scaffoldBackgroundColor: amoled ? Colors.black : (dark ? const Color(0xFF0A0E13) : const Color(0xFFE3EBF3)),
    appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, scrolledUnderElevation: 0),
  );
}

class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final VoidCallback? onTap;
  final Color? color;
  const Panel({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.onTap, this.color});
  @override
  Widget build(BuildContext context) {
    final border = isDark(context) ? Colors.white10 : Colors.black12;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: color ?? cardOf(context),
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22), side: BorderSide(color: border)),
        child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}

class ScreenFrame extends StatefulWidget {
  final String title;
  final String? subtitle;
  final List<Widget> actions, children;
  const ScreenFrame({super.key, required this.title, this.subtitle, this.actions = const [], required this.children});
  @override
  State<ScreenFrame> createState() => _ScreenFrameState();
}

class _ScreenFrameState extends State<ScreenFrame> {
  final sc = ScrollController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  Widget _strip(BuildContext c, double t, bool top, double h) {
    if (t < 0.02) return const SizedBox.shrink();
    final bg = bgOf(c);
    Widget layer(double frac) => Positioned(
          top: top ? 0 : null,
          bottom: top ? null : 0,
          left: 0,
          right: 0,
          height: h * frac,
          child: ClipRect(
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 5 * t, sigmaY: 5 * t),
              child: const SizedBox.expand(),
            ),
          ),
        );
    return Positioned(
      top: top ? 0 : null,
      bottom: top ? null : 0,
      left: 0,
      right: 0,
      height: h,
      child: IgnorePointer(
        child: Stack(children: [
          layer(1),
          layer(0.66),
          layer(0.33),
          Positioned.fill(
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: top ? Alignment.topCenter : Alignment.bottomCenter,
                  end: top ? Alignment.bottomCenter : Alignment.topCenter,
                  colors: [bg.withOpacity(0.85 * t), bg.withOpacity(0)],
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;
    return Stack(children: [
      ListView(
        controller: sc,
        padding: EdgeInsets.fromLTRB(16, topPad + 12, 16, 130),
        children: [
          Row(children: [
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                if (widget.subtitle != null) Text(widget.subtitle!, style: TextStyle(color: subtleOf(context))),
                Text(widget.title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)),
              ]),
            ),
            ...widget.actions.map((a) => Padding(padding: const EdgeInsets.only(left: 8), child: a)),
          ]),
          const SizedBox(height: 16),
          ...widget.children,
        ],
      ),
      if (store.blurOn)
        Positioned.fill(
          child: AnimatedBuilder(
            animation: sc,
            builder: (c, _) {
              double off = 0, mx = 0;
              if (sc.hasClients && sc.position.hasContentDimensions) {
                off = sc.offset;
                mx = sc.position.maxScrollExtent;
              }
              final tt = (off / 50).clamp(0.0, 1.0).toDouble();
              final bt = ((mx - off) / 50).clamp(0.0, 1.0).toDouble();
              return Stack(children: [_strip(c, tt, true, topPad + 36), _strip(c, bt, false, 150)]);
            },
          ),
        ),
    ]);
  }
}

Widget sectionTitle(BuildContext c, String t) => Padding(
      padding: const EdgeInsets.fromLTRB(4, 8, 4, 10),
      child: Text(t, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
    );

Future<double?> askNumber(BuildContext context, String title, double initial) {
  final ctl = TextEditingController(text: fmt(initial));
  return showDialog<double>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('Cancel')),
        FilledButton(
          onPressed: () => Navigator.pop(c, double.tryParse(ctl.text.replaceAll(',', '.'))),
          child: const Text('OK'),
        ),
      ],
    ),
  );
}

class NumStepper extends StatelessWidget {
  final double value, step, min;
  final bool isInt;
  final String suffix;
  final ValueChanged<double> onChanged;
  const NumStepper({
    super.key, required this.value, required this.step, required this.onChanged,
    this.isInt = false, this.min = 0, this.suffix = '',
  });

  double _r(double v) => double.parse(v.toStringAsFixed(2));

  @override
  Widget build(BuildContext context) {
    Widget btn(IconData i, VoidCallback f) => InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: f,
          child: SizedBox(width: 38, height: 44, child: Icon(i, size: 18)),
        );
    return Container(
      height: 44,
      decoration: BoxDecoration(color: fieldOf(context), borderRadius: BorderRadius.circular(22)),
      child: Row(children: [
        btn(Icons.remove, () => onChanged(math.max(min, _r(value - step)))),
        Expanded(
          child: InkWell(
            onTap: () async {
              final v = await askNumber(context, 'Enter value', value);
              if (v != null) onChanged(math.max(min, isInt ? v.roundToDouble() : v));
            },
            child: Center(
              child: Text('${isInt ? value.toInt().toString() : fmt(value)}$suffix',
                  style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
            ),
          ),
        ),
        btn(Icons.add, () => onChanged(_r(value + step))),
      ]),
    );
  }
}

// ---------------------------------------------------------------- charts
class LineChartW extends StatelessWidget {
  final List<double> ys;
  final double height;
  const LineChartW({super.key, required this.ys, this.height = 140});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        width: double.infinity,
        child: CustomPaint(painter: _LinePainter(ys, accentOf(context), isDark(context) ? Colors.white12 : Colors.black12)),
      );
}

class _LinePainter extends CustomPainter {
  final List<double> ys;
  final Color color, grid;
  _LinePainter(this.ys, this.color, this.grid);
  @override
  void paint(Canvas c, Size s) {
    for (var i = 0; i < 4; i++) {
      final y = s.height * i / 3;
      c.drawLine(Offset(0, y), Offset(s.width, y), Paint()..color = grid);
    }
    if (ys.isEmpty) return;
    final mn = ys.reduce(math.min), mx = ys.reduce(math.max);
    final span = (mx - mn) == 0 ? 1.0 : (mx - mn);
    const pad = 10.0;
    final w = s.width - 2 * pad, h = s.height - 2 * pad;
    Offset pt(int i) => Offset(pad + (ys.length == 1 ? w / 2 : w * i / (ys.length - 1)),
        pad + h * (1 - (ys[i] - mn) / (ys.length == 1 ? 2 : span)));
    final path = Path()..moveTo(pt(0).dx, pt(0).dy);
    for (var i = 1; i < ys.length; i++) {
      path.lineTo(pt(i).dx, pt(i).dy);
    }
    c.drawPath(path, Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeJoin = StrokeJoin.round);
    for (var i = 0; i < ys.length; i++) {
      c.drawCircle(pt(i), 4, Paint()..color = color);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

class BarChartW extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final double? goal;
  final double height;
  const BarChartW({super.key, required this.values, required this.labels, this.goal, this.height = 140});
  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        width: double.infinity,
        child: CustomPaint(painter: _BarPainter(values, labels, goal, accentOf(context), subtleOf(context))),
      );
}

class _BarPainter extends CustomPainter {
  final List<double> v;
  final List<String> l;
  final double? goal;
  final Color color, text;
  _BarPainter(this.v, this.l, this.goal, this.color, this.text);
  @override
  void paint(Canvas c, Size s) {
    if (v.isEmpty) return;
    final g = goal;
    final mx = math.max(1.0, math.max(v.reduce(math.max), g ?? 0));
    final chartH = s.height - 18;
    final slot = s.width / v.length;
    final bw = slot * 0.55;
    for (var i = 0; i < v.length; i++) {
      final h = chartH * (v[i] / mx);
      final r = RRect.fromRectAndRadius(
          Rect.fromLTWH(slot * i + (slot - bw) / 2, chartH - math.max(h, 2), bw, math.max(h, 2)), const Radius.circular(6));
      c.drawRRect(r, Paint()..color = color.withOpacity(v[i] == 0 ? 0.25 : 1));
      final tp = TextPainter(
        text: TextSpan(text: l[i], style: TextStyle(color: text, fontSize: 10)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: slot);
      tp.paint(c, Offset(slot * i + (slot - tp.width) / 2, chartH + 4));
    }
    if (g != null) {
      final y = chartH - chartH * g / mx;
      c.drawLine(Offset(0, y), Offset(s.width, y), Paint()..color = text..strokeWidth = 1);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

class HeatGrid extends StatelessWidget {
  final Set<String> checks;
  final Color color;
  final int weeks;
  final DateTime today;
  const HeatGrid({super.key, required this.checks, required this.color, required this.weeks, required this.today});
  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (c, box) {
        const gap = 4.0;
        final cell = (box.maxWidth - gap * (weeks - 1)) / weeks;
        final h = cell * 7 + gap * 6;
        return SizedBox(height: h, width: box.maxWidth, child: CustomPaint(painter: _HeatPainter(checks, color, weeks, today, cell, gap)));
      });
}

class _HeatPainter extends CustomPainter {
  final Set<String> checks;
  final Color color;
  final int weeks;
  final DateTime today;
  final double cell, gap;
  _HeatPainter(this.checks, this.color, this.weeks, this.today, this.cell, this.gap);
  @override
  void paint(Canvas c, Size s) {
    final mon = mondayOf(today);
    for (var col = 0; col < weeks; col++) {
      for (var row = 0; row < 7; row++) {
        final d = addDays(mon, (col - (weeks - 1)) * 7 + row);
        if (d.isAfter(today)) continue;
        final on = checks.contains(dkey(d));
        final rect = RRect.fromRectAndRadius(
            Rect.fromLTWH(col * (cell + gap), row * (cell + gap), cell, cell), Radius.circular(cell * 0.3));
        c.drawRRect(rect, Paint()..color = on ? color : color.withOpacity(0.14));
        if (d == today) {
          c.drawRRect(rect, Paint()
            ..color = color
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5);
        }
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}
