import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'data.dart';
import 'ui.dart';
import 'gym.dart';
import 'walk.dart';
import 'progress.dart';
import 'habits.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  store = await Store.load();
  applyRefresh(store.hz120);
  runApp(const GymApp());
}

class GymApp extends StatelessWidget {
  const GymApp({super.key});
  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final m = store.themeMode;
        return MaterialApp(
          title: 'Gym Tracker',
          debugShowCheckedModeBanner: false,
          themeMode: m == 'light' ? ThemeMode.light : (m == 'system' ? ThemeMode.system : ThemeMode.dark),
          theme: buildTheme(Brightness.light),
          darkTheme: buildTheme(Brightness.dark, amoled: m == 'amoled'),
          home: const Shell(),
        );
      },
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> with WidgetsBindingObserver {
  int idx = 0;
  static const pages = <Widget>[HomeScreen(), WalkScreen(), RecoveryScreen(), ProgressScreen(), HabitsScreen()];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => StepService.start());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) {
      store.refresh();
      StepService.start();
      applyRefresh(store.hz120);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = isDark(context);
    return Scaffold(
      body: Stack(children: [
        if (!isAmoled(context))
          Positioned(
            top: 0, left: 0, right: 0, height: 420,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    (dark ? const Color(0xFF0D3B4C) : const Color(0xFFBBD5F2)).withOpacity(dark ? 0.6 : 0.9),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),
        IndexedStack(index: idx, children: pages),
        Positioned(
          left: 18, right: 18,
          bottom: MediaQuery.of(context).padding.bottom + 10,
          child: _NavBar(idx: idx, onTap: (i) => setState(() => idx = i)),
        ),
      ]),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int idx;
  final ValueChanged<int> onTap;
  const _NavBar({required this.idx, required this.onTap});

  static const items = [
    (Icons.home_outlined, Icons.home, 'Home'),
    (Icons.directions_walk_outlined, Icons.directions_walk, 'Walk'),
    (Icons.accessibility_new_outlined, Icons.accessibility_new, 'Recovery'),
    (Icons.fitness_center_outlined, Icons.fitness_center, 'Gym'),
    (Icons.checklist_outlined, Icons.checklist, 'Habits'),
  ];

  @override
  Widget build(BuildContext context) {
    final accent = accentOf(context);
    final dark = isDark(context);
    return ClipRRect(
      borderRadius: BorderRadius.circular(36),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 24, sigmaY: 24),
        child: Container(
          height: 70,
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: cardOf(context).withOpacity(dark ? 0.62 : 0.72),
            borderRadius: BorderRadius.circular(36),
            border: Border.all(color: dark ? Colors.white12 : Colors.black12),
          ),
          child: Row(children: [
            for (var i = 0; i < items.length; i++)
              Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onTap(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    decoration: BoxDecoration(
                      color: i == idx ? accent.withOpacity(0.22) : Colors.transparent,
                      borderRadius: BorderRadius.circular(28),
                    ),
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Icon(i == idx ? items[i].$2 : items[i].$1, size: 24, color: i == idx ? accent : subtleOf(context)),
                      const SizedBox(height: 2),
                      Text(items[i].$3,
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: i == idx ? FontWeight.w700 : FontWeight.w500,
                            color: i == idx ? accent : subtleOf(context),
                          )),
                    ]),
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}
