import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'data.dart';
import 'ui.dart';

const cMint = Color(0xFF6EF0C2);
const cLime = Color(0xFF39D353);

String thousands(int n) {
  final s = n.toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write(',');
    b.write(s[i]);
  }
  return b.toString();
}

class StepService {
  static StreamSubscription<StepCount>? _sub;
  static String status = 'init';

  static Future<void> start() async {
    try {
      var st = await Permission.activityRecognition.status;
      if (!st.isGranted) st = await Permission.activityRecognition.request();
      if (!st.isGranted) {
        status = st.isPermanentlyDenied ? 'blocked' : 'denied';
        store.ping();
        return;
      }
      await _sub?.cancel();
      _sub = Pedometer.stepCountStream.listen(
        (e) => store.onRaw(e.steps),
        onError: (_) {
          status = 'error';
          store.ping();
        },
      );
      status = 'ok';
    } catch (_) {
      status = 'error';
    }
    store.ping();
  }
}

class WalkScreen extends StatelessWidget {
  const WalkScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: store,
      builder: (context, _) {
        final t = store.today;
        final today = store.steps[store.todayKey] ?? 0;
        final goal = store.stepGoal;
        final pct = (today / goal).clamp(0.0, 1.0).toDouble();
        final mon = mondayOf(t);
        final week = [for (var i = 0; i < 7; i++) (store.steps[dkey(addDays(mon, i))] ?? 0)];
        final streak = store.stepStreak();
        final allDays = store.steps.values.where((v) => v > 0).toList();
        final best = allDays.isEmpty ? 0 : allDays.reduce(math.max);
        final last7 = [for (var i = 0; i < 7; i++) (store.steps[dkey(addDays(t, -i))] ?? 0)];
        final avg = (last7.reduce((a, b) => a + b) / 7).round();
        final chip = today >= goal ? 'Goal reached 🎉' : (pct >= 0.5 ? 'On track' : 'Keep moving');

        return ScreenFrame(
          title: 'Walk',
          subtitle: niceDate(t),
          actions: [
            IconButton.filledTonal(
              tooltip: 'Add steps manually',
              icon: const Icon(Icons.add),
              onPressed: () async {
                final v = await askNumber(context, 'Add steps', 1000);
                if (v != null) store.addSteps(v.round());
              },
            ),
          ],
          children: [
            if (StepService.status == 'denied' || StepService.status == 'blocked')
              Panel(
                child: Row(children: [
                  const Icon(Icons.directions_walk, color: Colors.amber),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Allow "Physical activity" so the app can count your steps.')),
                  FilledButton.tonal(
                    onPressed: () => StepService.status == 'blocked' ? openAppSettings() : StepService.start(),
                    child: Text(StepService.status == 'blocked' ? 'Settings' : 'Allow'),
                  ),
                ]),
              ),
            if (StepService.status == 'error')
              Panel(child: Text('This phone has no step sensor, so use the + button to add steps by hand.', style: TextStyle(color: subtleOf(context)))),
            Panel(
              child: Column(children: [
                SizedBox(
                  height: 260,
                  width: 260,
                  child: CustomPaint(
                    painter: _TickRing(pct, cMint, subtleOf(context).withOpacity(0.25)),
                    child: Center(
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(thousands(today), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w800)),
                        Text('steps', style: TextStyle(color: subtleOf(context))),
                        const SizedBox(height: 6),
                        Text('${(pct * 100).round()}% of ${thousands(goal)}', style: const TextStyle(fontWeight: FontWeight.w600)),
                        const SizedBox(height: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            border: Border.all(color: subtleOf(context).withOpacity(0.4)),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text(chip, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ),
                      ]),
                    ),
                  ),
                ),
              ]),
            ),
            Panel(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Icon(Icons.local_fire_department, color: Color(0xFFFF5A1F), size: 46),
                  const SizedBox(width: 12),
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('STREAK', style: TextStyle(color: subtleOf(context), letterSpacing: 1.5, fontSize: 12)),
                    Text('$streak ${streak == 1 ? 'DAY' : 'DAYS'}', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
                  ]),
                ]),
                const SizedBox(height: 16),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  for (var i = 0; i < 7; i++) _dayCircle(context, addDays(mon, i), week[i], goal, pct),
                ]),
                const SizedBox(height: 18),
                Row(children: [
                  Text('STEPS', style: TextStyle(color: subtleOf(context), letterSpacing: 1.5, fontSize: 12)),
                  const Spacer(),
                  Text('${(pct * 100).round()}%', style: TextStyle(color: subtleOf(context))),
                ]),
                const SizedBox(height: 4),
                Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(thousands(today), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w800)),
                  Text(' / ${thousands(goal)}', style: TextStyle(color: subtleOf(context))),
                ]),
                const SizedBox(height: 10),
                Container(
                  height: 10,
                  decoration: BoxDecoration(color: fieldOf(context), borderRadius: BorderRadius.circular(6)),
                  child: FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: pct == 0 ? 0.01 : pct,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: cLime,
                        borderRadius: BorderRadius.circular(6),
                        boxShadow: [BoxShadow(color: cLime.withOpacity(0.55), blurRadius: 10)],
                      ),
                    ),
                  ),
                ),
              ]),
            ),
            Row(children: [
              _stat(context, (today * 0.00075).toStringAsFixed(2), 'km today'),
              const SizedBox(width: 10),
              _stat(context, '${(today * 0.04).round()}', 'kcal burned'),
              const SizedBox(width: 10),
              _stat(context, '${(today / 100).round()}', 'active min'),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              _stat(context, thousands(avg), '7-day average'),
              const SizedBox(width: 10),
              _stat(context, thousands(best), 'best day'),
            ]),
            sectionTitle(context, 'This week'),
            Panel(
              child: BarChartW(
                values: [for (final v in week) v.toDouble()],
                labels: weekdayNames,
                goal: goal.toDouble(),
              ),
            ),
            Panel(
              child: Row(children: [
                const Expanded(child: Text('Daily step goal', style: TextStyle(fontWeight: FontWeight.w700))),
                SizedBox(
                  width: 160,
                  child: NumStepper(
                    value: goal.toDouble(), step: 500, isInt: true, min: 1000,
                    onChanged: (v) {
                      store.stepGoal = v.toInt();
                      store.save();
                    },
                  ),
                ),
              ]),
            ),
            Text(
              'Steps come from your phone sensor, which keeps counting while the app is closed. They are added when you open the app. Distance and calories are estimates.',
              style: TextStyle(color: subtleOf(context), fontSize: 12),
            ),
          ],
        );
      },
    );
  }

  Widget _stat(BuildContext c, String v, String l) => Expanded(
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
          decoration: BoxDecoration(
            color: cardOf(c),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: isDark(c) ? Colors.white10 : Colors.black12),
          ),
          child: Column(children: [
            Text(v, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(l, style: TextStyle(color: subtleOf(c), fontSize: 11)),
          ]),
        ),
      );

  Widget _dayCircle(BuildContext c, DateTime d, int steps, int goal, double pct) {
    final isToday = d == store.today;
    final hit = steps >= goal;
    Widget inner;
    if (hit) {
      inner = Container(
        width: 38, height: 38,
        decoration: const BoxDecoration(color: cLime, shape: BoxShape.circle),
        child: const Icon(Icons.check, color: Colors.black, size: 20),
      );
    } else if (isToday) {
      inner = SizedBox(
        width: 38, height: 38,
        child: CircularProgressIndicator(value: pct, strokeWidth: 3.5, color: cLime, backgroundColor: fieldOf(c)),
      );
    } else {
      inner = Container(width: 38, height: 38, decoration: BoxDecoration(color: fieldOf(c), shape: BoxShape.circle));
    }
    return Column(children: [
      inner,
      const SizedBox(height: 6),
      Text(weekdayNames[d.weekday - 1], style: TextStyle(color: subtleOf(c), fontSize: 11)),
    ]);
  }
}

class _TickRing extends CustomPainter {
  final double pct;
  final Color on, off;
  _TickRing(this.pct, this.on, this.off);

  @override
  void paint(Canvas c, Size s) {
    const n = 60;
    final center = Offset(s.width / 2, s.height / 2);
    final r = math.min(s.width, s.height) / 2 - 4;
    final lit = (pct * n).round();
    for (var i = 0; i < n; i++) {
      final a = -math.pi / 2 + i * 2 * math.pi / n;
      final dir = Offset(math.cos(a), math.sin(a));
      final p = Paint()
        ..color = i < lit ? on : off
        ..strokeWidth = 5
        ..strokeCap = StrokeCap.round;
      c.drawLine(center + dir * (r - 20), center + dir * r, p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}
