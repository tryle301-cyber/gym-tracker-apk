import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'data.dart';
import 'ui.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _themeRow(BuildContext c, List<(String, String, IconData)> o) => Row(children: [
        for (var i = 0; i < o.length; i++) ...[
          if (i > 0) const SizedBox(width: 10),
          Expanded(child: _tile(c, o[i].$1, o[i].$2, o[i].$3)),
        ],
      ]);

  Widget _tile(BuildContext c, String v, String label, IconData icon) {
    final sel = store.themeMode == v;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () {
        store.themeMode = v;
        store.save();
      },
      child: Container(
        height: 92,
        decoration: BoxDecoration(
          color: sel ? accentOf(c).withOpacity(0.16) : cardOf(c),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: sel ? accentOf(c) : (isDark(c) ? Colors.white10 : Colors.black12), width: sel ? 2 : 1),
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 28),
          const SizedBox(height: 8),
          Text(label, style: TextStyle(fontWeight: sel ? FontWeight.w800 : FontWeight.w500)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings', style: TextStyle(fontWeight: FontWeight.w800))),
      body: ListenableBuilder(
        listenable: store,
        builder: (context, _) => ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
          const Padding(padding: EdgeInsets.fromLTRB(4, 4, 4, 10), child: Text('Theme', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700))),
          _themeRow(context, const [('system', 'Follow system', Icons.brightness_auto), ('light', 'Light', Icons.light_mode_outlined)]),
          const SizedBox(height: 10),
          _themeRow(context, const [('dark', 'Dark', Icons.dark_mode_outlined), ('amoled', 'AMOLED', Icons.contrast)]),
          const SizedBox(height: 6),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 4, 4, 14),
            child: Text('AMOLED uses pure black so the screen pixels switch off on OLED phones.',
                style: TextStyle(color: subtleOf(context), fontSize: 12)),
          ),
          Panel(
            child: Column(children: [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Always use 120 Hz', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Asks your phone for its highest refresh rate. Battery saver can still limit it.'),
                value: store.hz120,
                onChanged: (v) {
                  store.hz120 = v;
                  applyRefresh(v);
                  store.save();
                },
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Blur while scrolling', style: TextStyle(fontWeight: FontWeight.w700)),
                subtitle: const Text('Soft blur at the top and bottom edges. Turn off if the app feels slow.'),
                value: store.blurOn,
                onChanged: (v) {
                  store.blurOn = v;
                  store.save();
                },
              ),
            ]),
          ),
          Panel(
            child: Row(children: [
              const Expanded(child: Text('Weekly workout goal', style: TextStyle(fontWeight: FontWeight.w700))),
              SizedBox(
                width: 140,
                child: NumStepper(
                  value: store.weeklyGoal.toDouble(), step: 1, isInt: true, min: 1,
                  onChanged: (v) {
                    store.weeklyGoal = math.min(7, math.max(1, v.toInt()));
                    store.save();
                  },
                ),
              ),
            ]),
          ),
          Panel(
            child: Row(children: [
              const Expanded(child: Text('Rest timer (seconds)', style: TextStyle(fontWeight: FontWeight.w700))),
              SizedBox(
                width: 140,
                child: NumStepper(
                  value: store.restSecs.toDouble(), step: 15, isInt: true, min: 15,
                  onChanged: (v) {
                    store.restSecs = v.toInt();
                    store.save();
                  },
                ),
              ),
            ]),
          ),
          Panel(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Backup', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text('Your data lives only on this phone. Copy a backup and paste it somewhere safe (notes, email, Drive).',
                  style: TextStyle(color: subtleOf(context), fontSize: 12)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: FilledButton.tonal(
                    onPressed: () async {
                      await Clipboard.setData(ClipboardData(text: store.exportJson()));
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup copied to clipboard.')));
                      }
                    },
                    child: const Text('Copy backup'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton(
                    onPressed: () async {
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (c) => AlertDialog(
                          title: const Text('Restore from clipboard?'),
                          content: const Text('This replaces all current data with the backup on your clipboard.'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                            FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Restore')),
                          ],
                        ),
                      );
                      if (ok != true) return;
                      final d = await Clipboard.getData('text/plain');
                      final err = store.importJson(d?.text ?? '');
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err ?? 'Backup restored.')));
                      }
                    },
                    child: const Text('Restore'),
                  ),
                ),
              ]),
            ]),
          ),
          Text('Gym Tracker 1.0 · fully offline · no accounts, no internet permission.',
              style: TextStyle(color: subtleOf(context), fontSize: 12)),
        ]),
      ),
    );
  }
}
